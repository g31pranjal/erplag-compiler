/*
Batch no. 82

AUTHORS : 
Pranjal Gupta (2013B4A7470P)
Tanaya Jha (2013B3A7304P)
*/

extern int checkSemantics(treeNode * head, symbolScope * sHead, int * errors);
