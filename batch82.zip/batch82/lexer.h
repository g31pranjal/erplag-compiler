/*
Batch no. 82

AUTHORS : 
Pranjal Gupta (2013B4A7470P)
Tanaya Jha (2013B3A7304P)
*/

#include "lexerDef.h"
#include <stdio.h>


extern void removeComments(char * filename1);

extern int setUpStream(char * filename);

extern token * getToken();
