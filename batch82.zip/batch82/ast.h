/*
Batch no. 82

AUTHORS : 
Pranjal Gupta (2013B4A7470P)
Tanaya Jha (2013B3A7304P)
*/

#include "lexerDef.h"
#include "parserDef.h"
#include "lexer.h"
#include "parser.h"


extern int constructAST(treeNode * head);

extern int printAST(treeNode * head);
