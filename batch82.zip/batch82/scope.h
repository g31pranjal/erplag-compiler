/*
Batch no. 82

AUTHORS : 
Pranjal Gupta (2013B4A7470P)
Tanaya Jha (2013B3A7304P)
*/


extern symbolScope * initScopeStructure(treeNode * head, int * errors);

extern int printScopeStructure(symbolScope * head);

extern symbolScope * resolveCurrentModule(symbolScope * currScope);
